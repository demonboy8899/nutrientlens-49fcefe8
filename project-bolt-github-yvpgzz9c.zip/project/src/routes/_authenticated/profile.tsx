import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { LogOut, User } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { Button, Card, SectionTitle, Stat } from "@/components/ui-kit";
import { supabase } from "@/integrations/supabase/client";
import { useProfile } from "@/lib/queries";
import { ACTIVITY_LEVELS, GOALS } from "@/lib/nutrition";

export const Route = createFileRoute("/_authenticated/profile")({
  head: () => ({
    meta: [
      { title: "Profile — NutrientLens" },
      {
        name: "description",
        content: "View your account details, macro targets and sign out.",
      },
      { property: "og:title", content: "Profile — NutrientLens" },
      { property: "og:description", content: "Account details and targets." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ProfilePage,
});

function ProfilePage() {
  const navigate = useNavigate();
  const { data: profile, isLoading } = useProfile();
  const [signingOut, setSigningOut] = useState(false);

  async function signOut() {
    setSigningOut(true);
    try {
      await supabase.auth.signOut();
      navigate({ to: "/auth" });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not sign out");
    } finally {
      setSigningOut(false);
    }
  }

  const goal = GOALS.find((g) => g.id === profile?.goal);
  const activity = ACTIVITY_LEVELS.find((a) => a.id === profile?.activity_level);

  return (
    <AppShell title="Profile" subtitle="Your account & targets">
      <Card className="text-center">
        <span className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-primary/15">
          <User className="h-8 w-8 text-primary" />
        </span>
        <h2 className="mt-3 text-2xl font-bold uppercase">
          {profile?.display_name ?? "Athlete"}
        </h2>
        <p className="label-caps mt-1">
          {goal?.label ?? profile?.goal ?? "—"} ·{" "}
          {activity?.label ?? profile?.activity_level ?? "—"}
        </p>
      </Card>

      <div className="mt-4">
        <SectionTitle>Body stats</SectionTitle>
        <Card>
          <div className="grid grid-cols-3 gap-3">
            <Stat
              value={profile?.age ?? "—"}
              label="Age"
            />
            <Stat
              value={profile?.height_cm ?? "—"}
              unit="cm"
              label="Height"
            />
            <Stat
              value={profile?.weight_kg ? Number(profile.weight_kg).toFixed(1) : "—"}
              unit="kg"
              label="Weight"
            />
          </div>
          <p className="mt-3 text-xs text-muted-foreground">
            Sex: {profile?.sex ?? "—"}
          </p>
        </Card>
      </div>

      <div className="mt-4">
        <SectionTitle>Daily targets</SectionTitle>
        <Card>
          <p className="numeric text-5xl text-primary">
            {profile?.calorie_target ?? "—"}
          </p>
          <p className="label-caps mt-1">kcal per day</p>
          <div className="mt-5 grid grid-cols-3 gap-3 border-t border-border pt-4">
            <Stat
              tone="primary"
              value={profile?.protein_target ?? "—"}
              unit="g"
              label="Protein"
            />
            <Stat
              value={profile?.carb_target ?? "—"}
              unit="g"
              label="Carbs"
            />
            <Stat
              tone="accent"
              value={profile?.fat_target ?? "—"}
              unit="g"
              label="Fat"
            />
          </div>
          <p className="mt-4 text-xs text-muted-foreground">
            Water goal {profile?.water_target_ml ?? "—"} ml
          </p>
        </Card>
      </div>

      <Button
        variant="danger"
        size="lg"
        className="mt-6"
        disabled={signingOut || isLoading}
        onClick={signOut}
      >
        <LogOut className="h-4 w-4" />
        {signingOut ? "Signing out…" : "Sign out"}
      </Button>
    </AppShell>
  );
}
